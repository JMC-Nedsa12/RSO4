
/**
 * Write a description of class MOverFlow here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MOverFlowException extends Exception
{
   

    /**
     * Constructor for objects of class MOverFlow
     */
    public MOverFlowException() {   
    }

    public MOverFlowException(String message) {
        super(message);
    }
}
