import java.util.*;

public class FAnaliza
{

    String vhod =   "AAABCCČKRAVAJENORAKOZAJEBREJA";//za ucenje
    String cipher_text = "AAAAAAAABBCCČKKJJJVEEENOORRZR";


    // frekvence za posamezne crke v :
    Map<Character, Integer> mapa = new HashMap<Character, Integer>();               //originalnem besedilu
    Map<Character, Integer> mapa_cipher = new HashMap<Character, Integer>();        //v kriptiranem besedilu

    List<Vnos> original = new ArrayList<Vnos>();
    List<Vnos> cipher = new ArrayList<Vnos>();

    // preslikovalne tabele za posamezne znake
    Map<Character, Character> c2o = new HashMap<Character, Character>();  // za pretvorbo iz cipher v originalno
    Map<Character, Character> o2c = new HashMap<Character, Character>();  // za pretvorbo iz originalne v cipher



    public Map getO2C(){
        return o2c;
    }

    public Map getC2O(){
        return c2o;
    }

    public void test(){
        System.out.println(mapa.size());
    }


    /** spodnji metodi sta enaki:  daj jih v eno samo */
    public void uci(String vhod){
        for(int i = 0; i<vhod.length(); i++){
            Integer val = mapa.get(vhod.charAt(i));
            if(val!=null)
                mapa.put(vhod.charAt(i), val+1);
            else
                mapa.put(vhod.charAt(i), 1);
        }
    }

    public void beri(String cipher){
        for(int i = 0; i<cipher.length(); i++){
            Integer val = mapa_cipher.get(cipher.charAt(i));
            if(val!=null)
                mapa_cipher.put(cipher.charAt(i), val+1);
            else
                mapa_cipher.put(cipher.charAt(i), 1);
        }
    }

    public void zdruziO2C(){
        for(int i = 0; i<original.size(); i++){
            o2c.put(original.get(i).c,cipher.get(i).c);
        }
    }

    public void zdruziC2O(){
        for(int i = 0; i<original.size(); i++){
            c2o.put(cipher.get(i).c,original.get(i).c);
        }
    }

    // generira urejene kolekcije fo frekvencah posameznih črk
    public void sortiraj(){
        original = posortiraj(mapa);
        cipher = posortiraj(mapa_cipher);
    }


    // vrne sortiran arrayList
    public List<Vnos> posortiraj(Map<Character, Integer> mapa){
        List<Vnos> seznam = new ArrayList<Vnos>();

        for (Map.Entry<Character, Integer> entry : mapa.entrySet()) {
            Vnos v = new Vnos();
            v.i = entry.getValue();
            v.c = entry.getKey();
            seznam.add(v);
        }


        Collections.sort(seznam);

        return seznam;
    }

    /**
     *    izpise pogostost pojavitve posameznega znaka
     */
    public void izpisiAnalizoPoCrkah(){

        for (Map.Entry<Character, Integer> entry : mapa.entrySet()) {
               Character key = entry.getKey();
               Integer value = entry.getValue();
               System.out.println(key+":"+value);
        }

    }


    /**
    *   razred Vnos
    *   objekt tega tipa mora biti primerljiv z drugimi istovrstnimi, sicer ga ne bo moč razvrstiti
    *
    *   da ne povzroča problemov z 'unchecked' vsled generika Collection.sort( kaj<T> ) dodamo tipizacijo k Comparable
    */
    class Vnos implements Comparable<Vnos>{
        Integer i;
        Character c;

        /** od najvecjega do najmanjsega
        *
        *   @return 0 ... enaka, -vrednost ce manjsi, +vrednost ce vecji
        */

        public int compareTo(Vnos vnos){
            Vnos pr = vnos;
            return pr.i-i;
        }

        public String toString(){
            return i+":"+c;
        }

    }

    /** DODANA metoda:  podaja sekvenco, ki smo jo izvajali na uri */
    public static void main(String[] args){
        
        FAnaliza a = new FAnaliza();    //naredi novo FAnaliza
        
        a.uci(a.vhod);                  //besedilo za učenje
        a.beri(a.cipher_text);          // kriptirano besedilo
        
        a.sortiraj();  // rezultati v arraylistu
        
        a.zdruziO2C();  //da translacijske tabele o2c in c2o
        a.zdruziC2O();
    }
    
}
