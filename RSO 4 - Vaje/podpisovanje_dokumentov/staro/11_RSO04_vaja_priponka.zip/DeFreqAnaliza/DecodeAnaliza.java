
/**
 * class DecodeAnaliza
 * 
 * @author (your name) 
 * @version (a version number or a date)
 * 
 * 
 * kaže, kako bi želeli uporabljati analizo
 * 
 */

import java.io.*;
import java.util.*;

public class DecodeAnaliza
{
    
    private String criptedName;
    private BufferedReader cripted;      //šifrirana datoteka
    
    private String vzorecName;
    private BufferedReader ucniVzorec;   //training datoteka
    
    /** se določi kot : criptedName=cript.txt --> decodedFileName=cript.dec.txt */
    private String decodedFileName;      //criptedName
    
    /** preslikovalna tabela iz cipher->original
     *     omogoča prekodiranje večih datotek, kot to tabelo že enkrat imamo
    */
    private Map<Character,Character> transTabela=null;
    
    //konstruktor : zagotavlja imena datotek
    public DecodeAnaliza(String vzorecName,String criptedName){
    }
     public DecodeAnaliza(){
    }
    
    //dekodira datoteko in rezultat zapiše v novo datoteko
    private void doDecode(){
                    
        // transTabela = analiza.getC2O();
        
    }
    
    
    /* prikaže vsebino datoteke :    true->dekodirano, false->sifriran original */
    public void showFile(boolean which){
    }
    
    
    
    /**
     * Main method - replace this comment with your own
     * 
     * @param          args   array of Strings
     * @return         none
     */
    public static void main(String[] args)
    {
        DecodeAnaliza da = new DecodeAnaliza(); //= new DecodeAnaliza(file1,file2);
        //if (da.transTabela==null){}
         
        
        da.showFile(false);
        da.doDecode();
        da.showFile(true);
        
        
        
    }
}
