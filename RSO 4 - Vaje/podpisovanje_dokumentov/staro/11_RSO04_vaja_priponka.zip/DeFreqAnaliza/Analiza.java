
/**
 * interface Analiza
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.*;

public interface Analiza
{
   /** vrne translacijsko tabelo za pretvorbo iz originala v ciphertext
    * 
    * @return o2c
   */ 
   public Map<Character,Character> getO2C();
   
   /** vrne translacijsko tabelo za pretvorbo iz ciphertext v original
    * 
    * @return c2o
   */ 
   public Map<Character,Character> getC2O();
   
   /** vrne status zastavice, ki označuje konec procesa analize
    * 
    * @return done
   */
   public boolean getDone();
}
