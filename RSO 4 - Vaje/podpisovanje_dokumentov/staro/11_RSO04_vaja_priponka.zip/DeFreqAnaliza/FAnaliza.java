
/**
 * class FAnaliza 
 * 
 * analira dve datoteki, podani s kontruktorjem razreda
 * in kreira dve translacijski tabeli: o2c in c2o
 * 
 * konstruktor je pisan tako, da sproži proces analize obeh podanih tabel in kreira
 * obe tabeli, po končani analizi, postavi zastavico 'done' na true
 * 
 * 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FAnaliza implements Analiza
{
   private boolean done=false;
}
