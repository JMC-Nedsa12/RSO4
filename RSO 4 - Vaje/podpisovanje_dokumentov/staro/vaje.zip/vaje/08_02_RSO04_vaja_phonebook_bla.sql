



create database phonebook DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
use phonebook; 


CREATE USER mojuser IDENTIFIED BY 'mojPass'; 

grant usage on *.* to mojuser@localhost identified by 'mojPass'; 
grant all privileges on phonebook.* to mojuser@localhost; 


CREATE TABLE oseba (
    id INT NOT NULL AUTO_INCREMENT, 
    username VARCHAR(30) NOT NULL,
	password VARCHAR (20) NOT NULL,
    email VARCHAR(30), 
    datum DATE NOT NULL, 
    telefon VARCHAR(40) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=INNODB;


INSERT INTO oseba values (default, 'loli', 'brgBBB','loli@gmailx.com',
                             '2009-09-14 10:33:11', '+386 41-444-444');


CREATE TABLE skupina (	
   id INT NOT NULL AUTO_INCREMENT,
   imeSkupine VARCHAR(30) NOT NULL,
   PRIMARY KEY (id)
)ENGINE=INNODB;



CREATE TABLE IF NOT EXISTS `skupina_rel_oseba` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_osebe` int(11) NOT NULL,
  `id_skupine` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_skupine` (`id_skupine`),
  KEY `id_osebe` (`id_osebe`)
) ENGINE=InnoDB AUTO_INCREMENT=1 ;

--
-- Omejitve tabel za povzetek stanja
--

--
-- Omejitve za tabelo `skupina_rel_oseba`
--
ALTER TABLE `skupina_rel_oseba`
  ADD CONSTRAINT `skupina_rel_oseba_ibfk_2` FOREIGN KEY (`id_skupine`) REFERENCES `skupina` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `skupina_rel_oseba_ibfk_1` FOREIGN KEY (`id_osebe`) REFERENCES `oseba` (`id`) ON DELETE CASCADE;

					 
